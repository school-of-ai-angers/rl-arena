# Dummy Player

This player will choose the same valid move every time: the first one