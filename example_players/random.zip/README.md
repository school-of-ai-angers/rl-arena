# Random Player

This player will choose a valid move uniformly at random every time